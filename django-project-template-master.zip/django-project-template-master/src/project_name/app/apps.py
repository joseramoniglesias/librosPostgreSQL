from django.apps import AppConfig


class {{ project_name|capfirst }}Config(AppConfig):
    name = '{{ project_name }}'
